package put.io.patterns.implement;

public class USBDeviceObserver implements SystemStateObserver{

    private int currentNumber = 0;
    @Override
    public void update(SystemMonitor monitor) {
        if (monitor.getLastSystemState().getUsbDevices() != this.currentNumber){
            System.out.println("Number of USB devices has been changed");
        }
        this.currentNumber = monitor.getLastSystemState().getUsbDevices();
    }
}
